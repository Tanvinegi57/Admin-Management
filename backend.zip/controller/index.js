module.exports = {
  AdminRegister: require("./AdminController"),
  userControllers: require("./userController"),
  departmentControllers: require("./departmentController"),
  eduControllers: require("./educationController"),
  salaryController: require("./SalaryController"),
  commonController: require("./commonController"),
};
