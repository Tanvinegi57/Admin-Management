module.exports={
    AdminRegister: require("./AdminController"),
    userControllers: require("./userController"),
}