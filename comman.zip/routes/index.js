module.exports = {
    AdminRoutes:require("./AdminRoutes"),
    userRouter: require("./userRoutes"),
  };