module.exports={
    AdminService: require("./AdminService"),
    userService: require("./userService"),
}