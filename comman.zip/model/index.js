module.exports = {
  AdminRegister: require("./AdminModel"),
   UserModel: require("./userModel"),
};
