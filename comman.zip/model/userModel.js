const { Sequelize, DataTypes } = require("sequelize");

const sequelize = require("../config/connectionDB").sequelize;

const User = sequelize.define(
  "User",
  {
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      allowNull: false,
      primaryKey: true,
    },
    name: {
      type: DataTypes.STRING,
      allowNull: false,
      trim: true,
    },
    email: {   
      type: DataTypes.STRING,
      trim: true,
      defaultValue: 0,
    },
    password: {
      type: DataTypes.STRING,
      defaultValue: 0,
    },
    DOB:{
      type:DataTypes.DATE,
    },
    Isblocked: {
      type: DataTypes.INTEGER,
      defaultValue: 0,
    },
    gender: {
      type: DataTypes.STRING,
      defaultValue: 0,
    },
    age: {
      type: DataTypes.STRING,
      defaultValue: 0,
    },
    address: {
      type: DataTypes.STRING,
      defaultValue: 0,
    },
    education:{
      type:DataTypes.STRING,
      defaultValue:null
    },
    salary:{
       type:DataTypes.STRING,
       defaultValue:0
    },
    department:{
      type:DataTypes.STRING,
      defaultValue:null
    },
  },
  {
    freezeTableName: true,
  }
);

module.exports = User;
