module.exports = {
  AdminService: require("./AdminService"),
  userService: require("./userService"),
  DepartmentSer: require("./DepartmentService"),
  EduService: require("./educationService"),
  SalaryService: require("./salaryService"),
  EmployeeDeptService: require("./empDept"),
  // CommonService: require("./commonService"),
  EmployeeEduService: require("./empEdu"),
  EmployeeSalaryService: require("./empSalary"),
};
